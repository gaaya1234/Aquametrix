#include "AquaMetrics.h"
#include <avr/wdt.h>
#include <EEPROM.h>
#include <FastCRC.h>
#include <SoftwareSerial.h>
#include "DHT.h"

using namespace std;

#define PH1        0xAB
#define PH2        0xCD
#define CMD_cardReq 0x20
#define CMD_transResp 0x22
#define CMD_envResp 0x26
#define DATA_Len_cardReq  0x04
#define DATA_Len_transResp  0x18
#define DATA_Len_envReq 0x08
#define ENDP1 0xDC
#define ENDP2 0xBA
#define Resp_CMD_cardReq   0x21
#define Resp_CMD_transResp   0x23
#define Resp_CMD_envReq 0x25
#define DATA_len_RespCardReq   0x0C
#define DATA_len_RespTransResp   0x18
#define ErrorTransTime 0xE1
#define ErrorWaterTank 0xF1
#define ErrorUserBalance 0xE2
#define ErrorTime 4000
#define waterMeterConst 1
#define DHTTYPE DHT11   // DHT 22  (AM2302)


int buzzerPin;
int addrAccumlatedLitre = 10;
SoftwareSerial temp1Serial(A8, 32); //RX, TX Atemp1
SoftwareSerial temp2Serial(A9, 34); //RX, TX Atemp2
SoftwareSerial temp3Serial(A10, 36); //RX, TX BoilerTemp
SoftwareSerial temp4Serial(A11, 38); //RX, TX Nozzle   Temp
SoftwareSerial temp5Serial(50, 40); //RX, TX  KioskTemp1
SoftwareSerial DataSerial(11, 12); // nogoon hawtantai holbogdoh serial


AquaMetrics::AquaMetrics(int waterLevelPin,
    int waterMeterPin,
    int nozzleStatePin,
    int valveHotWaterRelayPin,
    int valveColdWaterRelayPin,
    int waterHotButtonPin,
    int waterColdButtonPin,
    int waterStopButtonPin,
    int buzzerPin,
    int displayEnablePin,
    int displayCLKPin,
    int displayDataPin,
	int sensorSmokePin,
	int sensorHumidityPin) { //constructor
  this->waterLevelPin = waterLevelPin;
  this->waterMeterPin =  waterMeterPin;
  this->nozzleStatePin = nozzleStatePin;
  this->valveHotWaterRelayPin = valveHotWaterRelayPin;
  this->valveColdWaterRelayPin = valveColdWaterRelayPin;
  this->waterHotButtonPin = waterHotButtonPin;
  this->waterColdButtonPin = waterColdButtonPin;
  this->waterStopButtonPin = waterStopButtonPin;
  this->buzzerPin = buzzerPin;
  this->displayEnablePin = displayEnablePin;
  this->displayCLKPin = displayCLKPin;
  this->displayDataPin = displayDataPin;
  this->sensorSmokePin = sensorSmokePin;
  this->sensorHumidityPin = sensorHumidityPin; //DHTTYPE DHT11   // DHT 22  (AM2302)
  init();
  

}

void AquaMetrics::init() { 
  
  //initialize
  pinMode(this->waterLevelPin, INPUT);
  pinMode(this->waterMeterPin, INPUT);
  pinMode(this->nozzleStatePin, INPUT_PULLUP);
  pinMode(this->valveHotWaterRelayPin, OUTPUT);
  pinMode(this->valveColdWaterRelayPin, OUTPUT);
  pinMode(this->waterHotButtonPin, INPUT_PULLUP);
  pinMode(this->waterColdButtonPin, INPUT_PULLUP);
  pinMode(this->waterStopButtonPin, INPUT_PULLUP);
  pinMode(this->buzzerPin, OUTPUT);
  pinMode(this->displayEnablePin, OUTPUT);
  pinMode(this->displayCLKPin, OUTPUT);
  pinMode(this->displayDataPin, OUTPUT);


  //attachInterrupt(this->digitalPinToInterrupt(waterMeterPin), funcINTwaterMeter, FALLING);
  //attachInterrupt(this->digitalPinToInterrupt(nozzleStatePin), funcINTnozzleState, LOW);
  
  digitalWrite(this->valveHotWaterRelayPin, LOW);
  digitalWrite(this->valveColdWaterRelayPin, LOW);
  Serial.begin(19200);
  buzzerPin = this->buzzerPin;
  
  temp1Serial.begin(9600);
  temp2Serial.begin(9600);
  temp3Serial.begin(9600);
  temp4Serial.begin(9600);
  temp5Serial.begin(9600);
  
}

void AquaMetrics::funcSetBuzzer1(){  // Make buzzer1 sound
  //Beep sound
    tone(this->buzzerPin, 1500); // Send 1KHz sound signal...
    delay(1000);        // ...for 1 sec
    noTone(this->buzzerPin); 
    delay(50);
    tone(this->buzzerPin, 1000);
    delay(200);  
    noTone(this->buzzerPin);     // Stop sound...
    delay(200);   
    tone(this->buzzerPin, 500);
    delay(200);  
    noTone(this->buzzerPin);     // Stop sound...
    delay(200);   
}

void AquaMetrics::funcSetBuzzer2(){  // Make buzzer2 sound
  digitalWrite(this->buzzerPin, HIGH);
  delay(50);
  digitalWrite(this->buzzerPin, LOW);
}


int AquaMetrics::funcGetWaterlevel(){
  waterTankLevel = analogRead(this->waterLevelPin);
  return waterTankLevel;
}


/*void AquaMetrics::funcINTwaterMeter(){
  this->transWaterMeter++;
}
/*
bool funcINTnozzleState(){
  this->nozzleState = !this->nozzleState;
  return this->nozzleState;
}*/

bool AquaMetrics::funcSetWaterValve(bool setType, uint8_t valve){ //true means open valve, false means close the valves
  if(setType){
    if(valve == 0x00){
      digitalWrite(this->valveHotWaterRelayPin, LOW);
      digitalWrite(this->valveColdWaterRelayPin, HIGH);
      return true;
    }
    else if(valve == 0x01){
      digitalWrite(this->valveHotWaterRelayPin, HIGH);
      digitalWrite(this->valveColdWaterRelayPin, LOW);
      return true;
    }
    else{
      digitalWrite(this->valveHotWaterRelayPin, LOW);
      digitalWrite(this->valveColdWaterRelayPin, LOW);
      return false;
    }
     
  }
  else{ 
     digitalWrite(this->valveHotWaterRelayPin, LOW);
     digitalWrite(this->valveColdWaterRelayPin, LOW);
     return true;
  }
}

int buttonCounter = 0;
unsigned long lastDebounceTime = 0;  // the last time the output pin was toggled
unsigned long debounceDelay = 50;    // the debounce time; increase if the output flickers
int buttonLastState = LOW;
int buttonState ;
int full=0;
boolean startMode = LOW;
boolean endMode = LOW;

void AquaMetrics::funcButtonPressed(int ButtonPin){
  int reading = digitalRead(ButtonPin);

      buttonState = reading;
      if (buttonState == HIGH)
      {
       ;
      }
      else
      {
        if(ButtonPin == waterHotButtonPin){
          this->waterHotButtonPressed = true;
          this->waterColdButtonPressed = false;
          this->waterStopButtonPressed = false;
          this->transWaterType = 0x01; //this->waterHotButtonPressed;
        }
        else if(ButtonPin == waterColdButtonPin){
          this->waterHotButtonPressed = false;
          this->waterColdButtonPressed = true;
          this->waterStopButtonPressed = false;
          this->transWaterType = 0x00; //this->waterColdButtonPressed;
        }
        else if(ButtonPin == waterStopButtonPin){
          this->waterHotButtonPressed = false;
          this->waterColdButtonPressed = false;
          this->waterStopButtonPressed = true;
        }
      }

}

void AquaMetrics::funcIsButtonPressed(){
  funcButtonPressed(waterHotButtonPin);
  funcButtonPressed(waterColdButtonPin);
  funcButtonPressed(waterStopButtonPin);
}

bool AquaMetrics::funcGetNozzleState(){
  if(digitalRead(nozzleStatePin)){
    nozzleState = false; //Nozzle Up
    return false;
  }
  else{
    nozzleState = true; //Nozzle Down
    return true;
  }
}



void AquaMetrics::funcLCDclkGenerator(){
    digitalWrite(this->displayCLKPin, HIGH);
    digitalWrite(this->displayCLKPin, LOW);
}

void AquaMetrics::funcLCDenableGenerator(){
    digitalWrite(this->displayEnablePin, HIGH);
    digitalWrite(this->displayEnablePin, LOW);
}

void AquaMetrics::funcLCDprint(int numbers){
  //set initial values to control pins
  digitalWrite(this->displayEnablePin,HIGH);
  digitalWrite(this->displayCLKPin,LOW);
  digitalWrite(this->displayDataPin,LOW);
  //prepare parameters:
  int lcd_print_digit;
  unsigned char data, data1;
  //get characters starting from 0 to N from the input string:
    //convert received number to LCd format number:
   if (numbers==0) lcd_print_digit=252;//2;          //252;    //0
  else if (numbers==1)  lcd_print_digit=96;//158;  //96;     //1
  else if (numbers==2)  lcd_print_digit=218;//36;  //218;      //2
  else if (numbers==3)  lcd_print_digit=242;//12;   //242;    //3
  else if (numbers==4)  lcd_print_digit=102;//152;  //102;    //4
  else if (numbers==5)  lcd_print_digit=182;//72;   //182;    //5
  else if (numbers==6)  lcd_print_digit=190;//64;   //190;    //6
  else if (numbers==7)  lcd_print_digit=224;//30;   //224;    //7
  else if (numbers==8)  lcd_print_digit=254;//0;    //254;    //8
  else if (numbers==9)  lcd_print_digit=246;//8;    //246;    //9
  else if (numbers==10) lcd_print_digit=253;//3;    //253;    //0.
  else if (numbers==11) lcd_print_digit=97;//159;  //97;     //1.
  else if (numbers==12) lcd_print_digit=219;//37;   //219;    //2.
  else if (numbers==13) lcd_print_digit=243;//13;   //243;    //3.
  else if (numbers==14) lcd_print_digit=103;//153;  //103;    //4.
  else if (numbers==15) lcd_print_digit=183;//73;   //183;    //5.
  else if (numbers==16) lcd_print_digit=191;//65;   //191;    //6.
  else if (numbers==17) lcd_print_digit=225;//31;   //225;    //7.
  else if (numbers==18) lcd_print_digit=255;//1;    //255;    //8.
  else if (numbers==19) lcd_print_digit=247;//9;    //247;    //9.
  else if (numbers==20) lcd_print_digit=0;//254;  //0;      //space
  else if (numbers==21) lcd_print_digit=255;//255;  //1;      //space.
  
  //Error code letters
  else if (numbers==30) lcd_print_digit=158;//96;  //158 //E
  else if (numbers==31) lcd_print_digit=142;//112;  //142 //F
  else if (numbers==32) lcd_print_digit=238;//16;  //238 //R
  else lcd_print_digit=252;//254;   //252
  //get characters starting from 0 to N from the input string:
  data=lcd_print_digit;
//bit0:
  data1 = data & ~0b11111110;
  if (     data1==0b00000001 ){
    digitalWrite(displayDataPin, HIGH);
    //Serial.print(1);
    }
  else{
    digitalWrite(displayDataPin, LOW);
    //Serial.print(0);
    }
  funcLCDclkGenerator();
  funcLCDenableGenerator();
  //bit1:
  data1 = data & ~0b11111101;
  if (     data1==0b00000010 ){
    digitalWrite(displayDataPin, HIGH);
    //Serial.print(1);
    }
  else{
    digitalWrite(displayDataPin, LOW);
    //Serial.print(0);
    }
  funcLCDclkGenerator();
  funcLCDenableGenerator();
  //bit2:
  data1 = data & ~0b11111011;
  if (     data1==0b00000100 ){
    digitalWrite(displayDataPin, HIGH);
    }
  else{
    digitalWrite(displayDataPin, LOW);
    //Serial.print(0);
    }
  funcLCDclkGenerator();
  funcLCDenableGenerator();
  //bit3:
  data1 = data & ~0b11110111;
  if (     data1==0b00001000 ){
    digitalWrite(displayDataPin, HIGH);
    }
  else{
    digitalWrite(displayDataPin, LOW);
    //Serial.print(0);
    }
  funcLCDclkGenerator();
  funcLCDenableGenerator();
  //bit4:
  data1 = data & ~0b11101111;
  if (     data1==0b00010000 ){
    digitalWrite(displayDataPin, HIGH);
    }
  else{
    digitalWrite(displayDataPin, LOW);
    //Serial.print(0);
    }
  funcLCDclkGenerator();
  funcLCDenableGenerator();
  //bit5:
  data1 = data & ~0b11011111;
  if (     data1==0b00100000 ){
    digitalWrite(displayDataPin, HIGH);
    }
  else{
    digitalWrite(displayDataPin, LOW);
    //Serial.print(0);
    }
  funcLCDclkGenerator();
  funcLCDenableGenerator();
  //bit6:
  data1 = data & ~0b10111111;
  if (     data1==0b01000000 ){
    digitalWrite(displayDataPin, HIGH);
   }
  else{
    digitalWrite(displayDataPin, LOW);
    //Serial.print(0);
    }
  funcLCDclkGenerator();
  funcLCDenableGenerator();
  //bit7:
  data1 = data & ~0b01111111;
  if (     data1==0b10000000 ){
    digitalWrite(displayDataPin, HIGH);
    }
  else{
    digitalWrite(displayDataPin, LOW);
    //Serial.print(0);
    }
  funcLCDclkGenerator();
  funcLCDenableGenerator();
  //set initial values to control pins
//  digitalWrite(pinEnable,HIGH);
//  digitalWrite(pinClock,LOW);
//  digitalWrite(pinData,LOW);
}

void AquaMetrics::funcLCDinit(){
    //functionClearLCD();
  int i,j;
  //clear LCD:
  for ( i=0; i<16; i++)  //how many digits to show on LCD?
  {
    if (i==0) j=0;
    else if (i==1) j=0;
    else if (i==2) j=5;
    else if (i==4) j=0;
//    else if (i==5)  j=0;
//    else if (i==6)  j=0;
    else if (i==10) j=0;
    else if (i==11) j=0;
    else if (i==12) j=10;
    else j=20;
    
    funcLCDprint(j);  
  }
}

void AquaMetrics::funcLCDanimation(){
   int a, b;
  for(a=0; a<22; a++){
    for(b=0; b<16; b++){
      funcLCDprint(a);
    }
    delay(1000);
  }
}

void AquaMetrics::funcLCDclear(){
  // for(int i=0; i<16; i++)
  //   funcLCDprint(20);
  int b;
  for(int a=0; a<16; a++)
  {
    if (a==0) {b=0;  funcLCDprint(b); }
    else if(a==1) {b=20;  funcLCDprint(b); }
    else if(a==2) {b=20;  funcLCDprint(b); }
    else if(a==3) {b=20;  funcLCDprint(b); }
    else if(a==4) {b=0;  funcLCDprint(b); }
    else if(a==5) {b=0;  funcLCDprint(b); }
    else if(a==6) {b=10;  funcLCDprint(b); }
    else if(a==7) {b=20;  funcLCDprint(b); }
    else if(a==8) {b=20;  funcLCDprint(b); }
    else if(a==9) {b=20;  funcLCDprint(b); }
    else if(a==10) {b=0;  funcLCDprint(b); }
    else if(a==11) {b=20;  funcLCDprint(b); }
    else if(a==12) {b=20;  funcLCDprint(b); }
    else if(a==13) {b=20;  funcLCDprint(b); }
    else if(a==14) {b=20;  funcLCDprint(b); }
    else if(a==15) {b=20;  funcLCDprint(b); }
    else {b=20; funcLCDprint(b); }
  }
}

//define variables
uint16_t unitPrice;
uint16_t totalLitreAmount;
uint16_t waterMileage;

void AquaMetrics::funcLCDdisplay(uint16_t totalLitreAmount, uint16_t unitPrice, int animCounter = 0){
  int i=0,j, b;
  int amountLine[6], priceDigitNumber, priceLine[4], amountDigitNumber, totalLine[6], totalDigitNumber;
  uint16_t totalPrice = totalLitreAmount*unitPrice;
  

  if(totalLitreAmount == 0)
  {	
		i=0;
		while(unitPrice > 0) //do till num greater than  0
		{
			priceLine[i++] = unitPrice % 10;  //split last digit from number
			unitPrice = unitPrice / 10;    //divide num by 10. num /= 10 also a valid one 
			priceDigitNumber = i;
		}
	  
	  for(int a=0; a<16; a++)
	  {
		if (a==0 & priceDigitNumber!=0) {b=priceLine[0]; priceDigitNumber--;  funcLCDprint(b); }
		else if(a==1 & priceDigitNumber!=0) {b=priceLine[1]; priceDigitNumber--;  funcLCDprint(b); }
		else if(a==2 & priceDigitNumber!=0) {b=priceLine[2]; priceDigitNumber--;  funcLCDprint(b); }
		else if(a==3 & priceDigitNumber!=0) {b=priceLine[3]; priceDigitNumber--;  funcLCDprint(b); }
		else if(a==4) {b=0;  funcLCDprint(b); }
		else if(a==5) {b=0;  funcLCDprint(b); }
		else if(a==6) {b=10;  funcLCDprint(b); }
		else if(a==10) {b=0;  funcLCDprint(b); }
		else {b=20; funcLCDprint(b); }
	  }
  }
  else{
	i=0;
	while(unitPrice > 0) //do till num greater than  0
	{
		priceLine[i++] = unitPrice % 10;  //split last digit from number
		unitPrice = unitPrice / 10;    //divide num by 10. num /= 10 also a valid one 
		priceDigitNumber = i;
	}
	
	i=0;
	while(totalLitreAmount > 0) //do till num greater than  0
	{
		amountLine[i++] = totalLitreAmount % 10;  //split last digit from number
		totalLitreAmount = totalLitreAmount / 10;    //divide num by 10. num /= 10 also a valid one 
		amountDigitNumber = i;
	}
	i=0;
	while(totalPrice > 0) //do till num greater than  0
	{
		totalLine[i++] = totalPrice % 10;  //split last digit from number
		totalPrice = totalPrice / 10;    //divide num by 10. num /= 10 also a valid one 
		totalDigitNumber = i;
	}
	
	
	for(int a=0; a<16; a++)
	{
		if (a==0 & priceDigitNumber!=0) {b=priceLine[0]; priceDigitNumber--;  funcLCDprint(b); }
		else if(a==1 & priceDigitNumber!=0) {b=priceLine[1]; priceDigitNumber--;  funcLCDprint(b); }
		else if(a==2 & priceDigitNumber!=0) {b=priceLine[2]; priceDigitNumber--;  funcLCDprint(b); }
		else if(a==3 & priceDigitNumber!=0) {b=priceLine[3]; priceDigitNumber--;  funcLCDprint(b); }
		else if(a==10 & totalDigitNumber!=0) {b=totalLine[0]; totalDigitNumber--;  funcLCDprint(b); }
		else if(a==11 & totalDigitNumber!=0) {b=totalLine[1]; totalDigitNumber--;  funcLCDprint(b); }
		else if(a==12 & totalDigitNumber!=0) {b=totalLine[2]; totalDigitNumber--;  funcLCDprint(b); }
		else if(a==13 & totalDigitNumber!=0) {b=totalLine[3]; totalDigitNumber--;  funcLCDprint(b); }
		else if(a==14 & totalDigitNumber!=0) {b=totalLine[4]; totalDigitNumber--;  funcLCDprint(b); }
		else if(a==15 & totalDigitNumber!=0) {b=totalLine[5]; totalDigitNumber--;  funcLCDprint(b); }
		else if(a==4 ) {b=animCounter%10;  funcLCDprint(b); }
		else if(a==5 ) {b=animCounter/10;  funcLCDprint(b); }
		else if(a==6 & amountDigitNumber!=0) {b=amountLine[0]; amountDigitNumber--;  funcLCDprint(b+10); }
		else if(a==7 & amountDigitNumber!=0) {b=amountLine[1]; amountDigitNumber--;  funcLCDprint(b); }
		else if(a==8 & amountDigitNumber!=0) {b=amountLine[2]; amountDigitNumber--;  funcLCDprint(b); }
		else if(a==9 & amountDigitNumber!=0) {b=amountLine[3]; amountDigitNumber--;  funcLCDprint(b); }

		else {b=20; funcLCDprint(b); }
	}
  }
  delay(100);
}

void AquaMetrics::funcLCDdisplayError(uint8_t Status){
  int a,b, temp1, temp2;
  if(Status == 0xE1)
  {
    temp1 = 30;
    temp2 = 1;
  }
  else if(Status == 0xE2)
  {
    temp1 = 30;
    temp2 = 2;
  }
  else if(Status == 0xF1)
  {
    temp1 = 31;
    temp2 = 1;
  }
  else if(Status == 0x0F)
  {
    temp1 = 0;
    temp2 = 31;
  }

  for(int a=0; a<16; a++)
  {
    if (a==0) {b=20;  funcLCDprint(b); }
    else if(a==1) {b=20;  funcLCDprint(b); }
    else if(a==2) {b=20;  funcLCDprint(b); }
    else if(a==3) {b=20;  funcLCDprint(b); }
    else if(a==4) {b=32;  funcLCDprint(b); }
    else if(a==5) {b=0;  funcLCDprint(b); }
    else if(a==6) {b=32;  funcLCDprint(b); }
    else if(a==7) {b=32;  funcLCDprint(b); }
    else if(a==8) {b=30;  funcLCDprint(b); }
    else if(a==9) {b=20;  funcLCDprint(b); }
    else if(a==10) {b=temp2;  funcLCDprint(b); }
    else if(a==11) {b=temp1;  funcLCDprint(b); }
    else if(a==12) {b=20;  funcLCDprint(b); }
    else if(a==13) {b=20;  funcLCDprint(b); }
    else if(a==14) {b=20;  funcLCDprint(b); }
    else if(a==15) {b=20;  funcLCDprint(b); }
    else {b=20; funcLCDprint(b); }
  }
  delay(100);
}

void AquaMetrics::funcLCDdisplayBalance(uint32_t cardBalance){
  int arr[6], i,j, total_digit, a, b;

  i=0;
  while(cardBalance > 0) //do till num greater than  0
  {
    arr[i++] = cardBalance % 10;  //split last digit from number
    cardBalance = cardBalance / 10;    //divide num by 10. num /= 10 also a valid one 
    total_digit = i;
  }

  for(a=0; a<16; a++)
  {
    if (a==0) {b=0; funcLCDprint(b); }
    else if(a==10 & total_digit!=0) {b=arr[0]; total_digit--;  funcLCDprint(b); }
    else if(a==11 & total_digit!=0) {b=arr[1]; total_digit--;  funcLCDprint(b); }
    else if(a==12 & total_digit!=0) {b=arr[2]; total_digit--;  funcLCDprint(b); }
    else if(a==13 & total_digit!=0) {b=arr[3]; total_digit--;  funcLCDprint(b); }
    else if(a==14 & total_digit!=0) {b=arr[4]; total_digit--;  funcLCDprint(b); }
    else if(a==15 & total_digit!=0) {b=arr[5]; total_digit--;  funcLCDprint(b); }
    else if(a==4) {b=0; funcLCDprint(b); }
	else if(a==5) {b=0; funcLCDprint(b); }
    else if(a==6) {b=10; funcLCDprint(b); }
    else {b=20; funcLCDprint(b); }
  }

  delay(100);
  
}

//--------------------------------------------------------------
//--------------------------------------------------------------

void Transaction::funcSetBuzzerCardReader(){
  //Beep sound
    tone(buzzerPin, 1500); // Send 1KHz sound signal...
    delay(300);        // ...for 1 sec
    noTone(buzzerPin); 
    delay(50);
    tone(buzzerPin, 1500);
    delay(300);  
    noTone(buzzerPin);     // Stop sound...
    delay(200);   
}

bool Transaction::funcCheckCRCpacket(uint8_t *buffer, uint8_t bufferSize){
  uint8_t temp[30];
  uint8_t j=0, k, i=0;
  for(i=2; i<bufferSize-3; i++){
        temp[j++] = buffer[i];
  }

  temp[j++] = NULL;
  uint16_t CRCchecked = 0x00, CRCreceived =0x00;
  FastCRC16 CRC16;
  CRCchecked = CRC16.kermit(temp, bufferSize-6);
  CRCreceived = (((buffer[i] & 0x00FF)<<8) | (buffer[i-1] & 0x00FF)) ;

  if(CRCchecked == CRCreceived)
    return true;
  else  
    return false;
}

bool Transaction::funcReadSerial(SoftwareSerial &DataSerial){
  int m, a, i;
  this->RECEIVED_FRAME[50]={0};
  //Serial.println();
  //Read received packet
  for(i=0; i<32; i++)
  {
    a=0;
    while ( !(Serial.available()>0 ) )    //if received
    {
      a++;
      delayMicroseconds(50);
      if (a>500){
        if(i == 20 | i== 32 | i == 7)
          return true;
        else
          return false;
      }  
        
    }
    this->RECEIVED_FRAME[i]=Serial.read();
    // Serial.print(this->RECEIVED_FRAME[i], HEX);
    // Serial.print("  ");
  } 
  return true;    
}

bool Transaction::funcRespRaspberry(SoftwareSerial &DataSerial){
  bool temp;
  temp = funcReadSerial(DataSerial);
  if(temp){
  
    /*     Print received serial data
    Serial.println();
    for(int i=0; i<(this->RECEIVED_FRAME[3]+8); i++){
      Serial.print(this->RECEIVED_FRAME[i] < 0x10 ? " 0" : " ");
      Serial.print(this->RECEIVED_FRAME[i], HEX);
      }
    */

    
    if(this->RECEIVED_FRAME[2] == Resp_CMD_cardReq) {   //If it has "Start Transaction" command

        if(funcCheckCRCpacket(this->RECEIVED_FRAME, this->RECEIVED_FRAME[3]+8) == true){
          //Serial.print("Zuw data");
          this->transCardUID[0] = this->RECEIVED_FRAME[4];
          this->transCardUID[1] = this->RECEIVED_FRAME[5];
          this->transCardUID[2] = this->RECEIVED_FRAME[6];
          this->transCardUID[3] = this->RECEIVED_FRAME[7]; 
          this->transCardBalance = (((this->RECEIVED_FRAME[8] & 0x000000FF) << 24) | ((this->RECEIVED_FRAME[9] & 0x000000FF) << 16) | ((this->RECEIVED_FRAME[10] & 0x000000FF) << 8) | ((this->RECEIVED_FRAME[11] & 0x000000FF)));
          this->transHotWaterUnitPrice = (((this->RECEIVED_FRAME[12] & 0x00FF) << 8) | (this->RECEIVED_FRAME[13] & 0x00FF));
          this->transColdWaterUnitPrice = (((this->RECEIVED_FRAME[14] & 0x00FF) << 8) | (this->RECEIVED_FRAME[15] & 0x00FF));
          
        }
        else {
          //DataSerial.println("Failed CRC error occured !!!");
          //Serial.println("Failed CRC error occured !!!");
        }
      return true;
    }
	
	else if(this->RECEIVED_FRAME[2] == Resp_CMD_envReq){
		//if(funcCheckCRCpacket(this->RECEIVED_FRAME, this->RECEIVED_FRAME[3]+8) == true){
          this->funcGetSensorData(); 
		  
		  //funcSetBuzzerCardReader();
		  return false;
        //else {
          //Serial.println("Failed CRC error occured !!!");
        //}

	}
    else if(this->RECEIVED_FRAME[2] == Resp_CMD_transResp){ //If it has "Confirm Transaction" command
  
        if(funcCheckCRCpacket(this->RECEIVED_FRAME, this->RECEIVED_FRAME[3]+8) == true){
          this->transConfirmStatus = this->RECEIVED_FRAME[27];
		  
		  //to read accumlatedWaterLitre from EEPROM
		  //this->accumlatedWaterLitre = ((EEPROM.read(addrAccumlatedLitre) << 0) & 0xFF) + ((EEPROM.read(addrAccumlatedLitre + 1) << 8)&0xFFFF) + ((EEPROM.read(addrAccumlatedLitre + 2) << 16) & 0xFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 3) << 24) & 0xFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 4) << 32) & 0xFFFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 5) << 40) & 0xFFFFFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 6) << 48) & 0xFFFFFFFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 7) << 56) & 0xFFFFFFFFFFFFFFFF);
		  //this->accumlatedWaterLitre = this->accumlatedWaterLitre + this->transWaterLitre;
		  
		  //to write accumlatedWaterLitre to EEPROM, EEPROM starting address is 10
		  //EEPROM.write(addrAccumlatedLitre, this->accumlatedWaterLitre & 0xFF);
		  //EEPROM.write(addrAccumlatedLitre + 1, (this->accumlatedWaterLitre >> 8) & 0xFF);
		  //EEPROM.write(addrAccumlatedLitre + 2, (this->accumlatedWaterLitre >> 16) & 0xFF);
		  //EEPROM.write(addrAccumlatedLitre + 3, (this->accumlatedWaterLitre >> 24) & 0xFF);
		  //EEPROM.write(addrAccumlatedLitre + 4, (this->accumlatedWaterLitre >> 32) & 0xFF);
		  //EEPROM.write(addrAccumlatedLitre + 5, (this->accumlatedWaterLitre >> 40) & 0xFF);
		  //EEPROM.write(addrAccumlatedLitre + 6, (this->accumlatedWaterLitre >> 48) & 0xFF);
		  //EEPROM.write(addrAccumlatedLitre + 7, (this->accumlatedWaterLitre >> 56) & 0xFF);
        }
        else {
          //Serial.println("Failed CRC error occured !!!");
        }
        this->transCardBalance = 0;
        return false;
       
    }

    return true;
  }
  else
    return false;
}

uint8_t *Transaction::funcSendCardReqCmd(){
  uint16_t CRC;
  this->SENDING_FRAME[50]={0};
  uint8_t tempArr[50]={0};
  this->SENDING_FRAME[0] = PH1; // Packet header AB
  this->SENDING_FRAME[1] = PH2; // Packet header CD
  this->SENDING_FRAME[2] = CMD_cardReq; // Command number
  this->SENDING_FRAME[3] = DATA_Len_cardReq; // Data length
  for (int i=0; i<sizeof(this->transCardUID); i++) {
    this->SENDING_FRAME[i+4] = this->transCardUID[i];
  }

  for(int i=2; i<8; i++)
    tempArr[i-2]=this->SENDING_FRAME[i];
  
  FastCRC16 CRC16;
  CRC = CRC16.kermit(tempArr, 6);
  this->SENDING_FRAME[8] = CRC & 0x00FF; // CRC LOW
  this->SENDING_FRAME[9] = (CRC & 0xFF00) >> 8; // CRC HIGH
  this->SENDING_FRAME[10] = ENDP1; // End of packet DC
  this->SENDING_FRAME[11] = ENDP2; // End of packet BA
  this->SENDING_FRAME[12] = NULL;
  
  for(int i=0; i<12; i++){
     Serial.write(SENDING_FRAME[i]);
    // Serial.print(" ");
    // DataSerial.write(SENDING_FRAME[i]);
  }
    

  return this->SENDING_FRAME;
}

uint8_t *Transaction::funcSendTransInfoCmd(){
  
  uint16_t CRC;
  uint8_t tempArr[50]={0};
  this->SENDING_FRAME[50]={0};
  this->SENDING_FRAME[0] = PH1; // Packet header AB
  this->SENDING_FRAME[1] = PH2; // Packet header CD
  this->SENDING_FRAME[2] = CMD_transResp; // Command number
  this->SENDING_FRAME[3] = DATA_Len_transResp; // Data length
  for (int i=0; i<sizeof(this->transCardUID); i++) {
    this->SENDING_FRAME[i+4] = this->transCardUID[i];
  }
  this->SENDING_FRAME[8] = (this->transHotWaterUnitPrice & 0xFF00) >> 8;
  this->SENDING_FRAME[9] = (this->transHotWaterUnitPrice & 0x00FF);
  this->SENDING_FRAME[10] = (this->transColdWaterUnitPrice & 0xFF00) >> 8;
  this->SENDING_FRAME[11] = (this->transColdWaterUnitPrice & 0x00FF);
  this->SENDING_FRAME[12] = this->transWaterType;
  this->SENDING_FRAME[13] = (this->transWaterLitre & 0xFF00) >> 8;
  this->SENDING_FRAME[14] = (this->transWaterLitre & 0x00FF);
  this->SENDING_FRAME[15] = (this->transWaterAmount & 0xFF000000) >> 24;
  this->SENDING_FRAME[16] = (this->transWaterAmount & 0x00FF0000) >> 16;
  this->SENDING_FRAME[17] = (this->transWaterAmount & 0x0000FF00) >> 8;
  this->SENDING_FRAME[18] = (this->transWaterAmount & 0x000000FF);
  this->SENDING_FRAME[19] = (this->accumlatedWaterLitre & 0xFF00000000000000) >> 56;
  this->SENDING_FRAME[20] = (this->accumlatedWaterLitre & 0x00FF000000000000) >> 48;
  this->SENDING_FRAME[21] = (this->accumlatedWaterLitre & 0x0000FF0000000000) >> 40;
  this->SENDING_FRAME[22] = (this->accumlatedWaterLitre & 0x000000FF00000000) >> 32;
  this->SENDING_FRAME[23] = (this->accumlatedWaterLitre & 0x00000000FF000000) >> 24;
  this->SENDING_FRAME[24] = (this->accumlatedWaterLitre & 0x0000000000FF0000) >> 16;
  this->SENDING_FRAME[25] = (this->accumlatedWaterLitre & 0x000000000000FF00) >> 8;
  this->SENDING_FRAME[26] = (this->accumlatedWaterLitre & 0x00000000000000FF);
  this->SENDING_FRAME[27] = this->transStatus;
  this->SENDING_FRAME[28] = NULL;
  for(int i=2; i<28; i++)
    tempArr[i-2]=this->SENDING_FRAME[i];
  
  FastCRC16 CRC16;
  CRC = CRC16.kermit(tempArr, 26);
  this->SENDING_FRAME[28] = CRC & 0x00FF; // CRC LOW
  this->SENDING_FRAME[29] = (CRC & 0xFF00) >> 8; // CRC HIGH
  this->SENDING_FRAME[30] = ENDP1; // End of packet DC
  this->SENDING_FRAME[31] = ENDP2; // End of packet BA
  this->SENDING_FRAME[32] = NULL;

  for(int i=0; i<32; i++){
    // Serial.print(SENDING_FRAME[i], HEX);
    // Serial.print(" ");
    Serial.write(SENDING_FRAME[i]);
  }
    
  return this->SENDING_FRAME;
}


void AquaMetrics::funcErrorTransactionTime(SoftwareSerial &raspberrySerial){
  
  this->transStatus = ErrorTransTime;
  this->funcCancelTransaction(raspberrySerial);
}

void AquaMetrics::funcErrorUserBalance(SoftwareSerial &raspberrySerial){
  
  this->transStatus = ErrorUserBalance;
  this->funcCancelTransaction(raspberrySerial);

}

void AquaMetrics::funcErrorWaterTank(SoftwareSerial &raspberrySerial){
  
  this->transStatus = ErrorWaterTank;
  this->funcCancelTransaction(raspberrySerial);

}

void AquaMetrics::funcCancelTransaction(SoftwareSerial &raspberrySerial){
  //Display error code
  unsigned long stTime = millis();
  uint8_t *sendingPacket;
  this->transStarted = false;
  funcLCDdisplayError(this->transStatus);
  //Close all valve
  funcSetWaterValve(false,0x02);
  //this->accumlatedWaterLitre = this->accumlatedWaterLitre + this->transWaterLitre;
  //to read accumlatedWaterLitre from EEPROM
  this->accumlatedWaterLitre = ((EEPROM.read(addrAccumlatedLitre) << 0) & 0xFF) + ((EEPROM.read(addrAccumlatedLitre + 1) << 8)&0xFFFF) + ((EEPROM.read(addrAccumlatedLitre + 2) << 16) & 0xFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 3) << 24) & 0xFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 4) << 32) & 0xFFFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 5) << 40) & 0xFFFFFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 6) << 48) & 0xFFFFFFFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 7) << 56) & 0xFFFFFFFFFFFFFFFF);
  this->accumlatedWaterLitre = this->accumlatedWaterLitre + this->transWaterMeter;
		  
  //to write accumlatedWaterLitre to EEPROM, EEPROM starting address is 10
  EEPROM.write(addrAccumlatedLitre, this->accumlatedWaterLitre & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 1, (this->accumlatedWaterLitre >> 8) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 2, (this->accumlatedWaterLitre >> 16) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 3, (this->accumlatedWaterLitre >> 24) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 4, (this->accumlatedWaterLitre >> 32) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 5, (this->accumlatedWaterLitre >> 40) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 6, (this->accumlatedWaterLitre >> 48) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 7, (this->accumlatedWaterLitre >> 56) & 0xFF);
  sendingPacket = funcSendTransInfoCmd();
  funcDumpByteArray(sendingPacket, sendingPacket[3]+8, raspberrySerial);
  this->transWaterMeter = 0;
  //Beep sound for 8 sec
  while((millis() - stTime) < ErrorTime){
      funcSetBuzzer2();
      //Serial.println(millis());
      delay(500);
  }
  //clear display
funcLCDclear();
}


void AquaMetrics::funcEndTransaction(SoftwareSerial &raspberrySerial){
  //Close all valve
  uint8_t *sendingPacket;
  this->transStarted = false;
  funcSetWaterValve(false,0x02);
  //Fill variables 
  this->transWaterLitre = this->transWaterMeter/waterMeterConst;
  
  if(this->transWaterType == 0x01)
    this->transWaterAmount = this->transWaterLitre * this->transHotWaterUnitPrice;
  else 
    this->transWaterAmount = this->transWaterLitre * this->transColdWaterUnitPrice;
    
  //this->accumlatedWaterLitre = this->accumlatedWaterLitre + this->transWaterLitre;
  //to read accumlatedWaterLitre from EEPROM
  this->accumlatedWaterLitre = ((EEPROM.read(addrAccumlatedLitre) << 0) & 0xFF) + ((EEPROM.read(addrAccumlatedLitre + 1) << 8)&0xFFFF) + ((EEPROM.read(addrAccumlatedLitre + 2) << 16) & 0xFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 3) << 24) & 0xFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 4) << 32) & 0xFFFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 5) << 40) & 0xFFFFFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 6) << 48) & 0xFFFFFFFFFFFFFF) + ((EEPROM.read(addrAccumlatedLitre + 7) << 56) & 0xFFFFFFFFFFFFFFFF);
  this->accumlatedWaterLitre = this->accumlatedWaterLitre + this->transWaterMeter;
		  
  //to write accumlatedWaterLitre to EEPROM, EEPROM starting address is 10
  EEPROM.write(addrAccumlatedLitre, this->accumlatedWaterLitre & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 1, (this->accumlatedWaterLitre >> 8) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 2, (this->accumlatedWaterLitre >> 16) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 3, (this->accumlatedWaterLitre >> 24) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 4, (this->accumlatedWaterLitre >> 32) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 5, (this->accumlatedWaterLitre >> 40) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 6, (this->accumlatedWaterLitre >> 48) & 0xFF);
  EEPROM.write(addrAccumlatedLitre + 7, (this->accumlatedWaterLitre >> 56) & 0xFF);
	
  //Serial.print((String)"Accumlated Water Litre " + this->accumlatedWaterLitre);
  this->transWaterMeter = 0;
  this->transStatus = 0x01;
  
  sendingPacket = funcSendTransInfoCmd();
  funcDumpByteArray(sendingPacket, sendingPacket[3]+8, raspberrySerial);
  //Accepted transaction beep sound
  funcSetBuzzer1();
// clear display
  //funcLCDclear();
}


//--------------------------------------------------------------
//--------------------------------------------------------------
//Declare variables and parameters
byte card_stx=0x02;
byte card_station_id=0x00;
byte card_data_length = 0x00;
byte card_read_cmd=0x20; 
byte card_write_cmd = 0x21;
byte card_key=0xFF;
byte card_req=0x00;
byte card_read_number_of_block=0x01;
byte card_start_block_address=0x04;
byte card_BCC =0x00;
byte card_etx=0x03;
byte card_read_cmd_buffer[15];
byte card_write_cmd_buffer[31];

const uint8_t PACKET_LENGTH = 26;
boolean collectPacket = false;
boolean packetAvailable = false;
boolean readenCard = false;
boolean powerOn = false;
uint8_t packetLength = 0;
byte incomingByte[PACKET_LENGTH];

byte temp1 = 0x02;
byte temp2 = 0x00;
byte temp3 = 0x15;

unsigned long startMillis;
unsigned long currentMillis;
const unsigned long period = 20000;  //the value is a number of milliseconds 
byte currentCardUID[5], oldCardUID[5]={0xff,0xff,0xff,0xff};

/*
void AquaMetrics::funcSetBuzzerCardReader()
{
  //Beep sound
    tone(this->buzzerPin, 1500); // Send 1KHz sound signal...
    delay(200);        // ...for 1 sec
    noTone(buzzerPin); 
    delay(50);
    tone(this->buzzerPin, 1500);
    delay(200);  
    noTone(this->buzzerPin);     // Stop sound...
    delay(200);   
}
*/

byte Transaction::funcCheckBCC(byte card_data_length, byte cmdType)
{
    byte BCC;
    BCC = card_station_id^card_data_length^cmdType^card_req^card_read_number_of_block^card_start_block_address^card_key^card_key^card_key^card_key^card_key^card_key;
    return BCC;
}

void Transaction::funcDumpByteArray(byte *buffer, byte bufferSize, SoftwareSerial &ChosenSerial)
{
    for (int pos=0 ; pos < bufferSize; pos++)
    {
        ChosenSerial.write(buffer[pos]);
        //Serial.print(buffer[pos] < 0x10 ? " 0" : " ");
        //Serial.print(buffer[pos], HEX);
    }
    //Serial.print("\n");
}

byte *Transaction::funcCardReadCmd(SoftwareSerial &CardSerial)
{
  memset(card_read_cmd_buffer,0,sizeof(card_read_cmd_buffer));
  card_read_cmd_buffer[0] = card_stx;
  card_read_cmd_buffer[1] = card_station_id;
  card_data_length = 0x0A;
  card_read_cmd_buffer[2] = card_data_length;
  card_read_cmd_buffer[3] = card_read_cmd;
  
  //Where and how many blocks to be readen?
  card_read_cmd_buffer[4] = card_req=0x01;
  card_read_cmd_buffer[5] = card_read_number_of_block;
  card_read_cmd_buffer[6] = card_start_block_address;
  
  //authenticate card default key
  card_read_cmd_buffer[7] = card_key;
  card_read_cmd_buffer[8] = card_key;
  card_read_cmd_buffer[9] = card_key;
  card_read_cmd_buffer[10] = card_key;
  card_read_cmd_buffer[11] = card_key;
  card_read_cmd_buffer[12] = card_key;
  
  //to calculate checksum
  card_read_cmd_buffer[13] = funcCheckBCC(card_data_length, card_read_cmd);
  card_read_cmd_buffer[14] = card_etx;

  //Print out read cmd
  this->funcDumpByteArray(card_read_cmd_buffer, sizeof(card_read_cmd_buffer), CardSerial);
  return card_read_cmd_buffer;
}

byte *Transaction::funcCardWriteCmd()
{
  memset(card_write_cmd_buffer,0,sizeof(card_write_cmd_buffer));
  card_write_cmd_buffer[0] = card_stx;
  card_write_cmd_buffer[1] = card_station_id;
  card_data_length = 0x1A;
  card_write_cmd_buffer[2] = card_data_length;
  card_write_cmd_buffer[3] = card_write_cmd;
  card_write_cmd_buffer[4] = card_req=0x01;
  card_write_cmd_buffer[5] = card_read_number_of_block=0x01;
  card_write_cmd_buffer[6] = card_start_block_address;
  //authenticate card default key
  card_write_cmd_buffer[7] = card_key;
  card_write_cmd_buffer[8] = card_key;
  card_write_cmd_buffer[9] = card_key;
  card_write_cmd_buffer[10] = card_key;
  card_write_cmd_buffer[11] = card_key;
  card_write_cmd_buffer[12] = card_key;
  //To write data
  card_write_cmd_buffer[13] = 0x00;
  card_write_cmd_buffer[14] = 0x00;
  card_write_cmd_buffer[15] = 0x00;
  card_write_cmd_buffer[16] = 0x00;
  card_write_cmd_buffer[17] = 0x00;
  card_write_cmd_buffer[18] = 0x00;
  card_write_cmd_buffer[19] = 0x00;
  card_write_cmd_buffer[20] = 0x00;
  card_write_cmd_buffer[21] = 0x01;  //1      pinCode
  card_write_cmd_buffer[22] = 0x15;  //21     pinCode
  card_write_cmd_buffer[23] = 0x01;  //1      pinCode
  card_write_cmd_buffer[24] = 0x15;  //21     pinCode
  card_write_cmd_buffer[25] = 0x00;
  card_write_cmd_buffer[26] = 0x00;
  card_write_cmd_buffer[27] = 0x00;
  card_write_cmd_buffer[28] = 0x32;  //1E means 30TUG, 32 means 50TUG, 64 means 100TUG
  //End part
  card_BCC = card_write_cmd_buffer[1];
  for(int i=2; i<27; i++){
    card_BCC = card_BCC^card_write_cmd_buffer[i];
  }
  card_write_cmd_buffer[29] = card_BCC;
  card_write_cmd_buffer[30] = card_etx;
  //funcDumpByteArray(card_write_cmd_buffer, sizeof(card_write_cmd_buffer));
  return card_write_cmd_buffer;
}

boolean Transaction::funcCheckReadenPacket(byte *buffer, byte bufferSize)
{
  byte respBCC;
  respBCC = buffer[1];
  for(int i=2; i<24; i++)
    respBCC = respBCC^buffer[i];
  //Serial.print((String)"Checked BCC--> ");
  //Serial.print(respBCC, HEX);
  if(buffer[24] == respBCC)
    return true;
  else
    return false;
}

void Transaction::sendPacketUSB(byte *buffer, byte bufferSize)
{
    for (int pos = 0 ; pos < bufferSize; pos++)    //4,8
    {
        Serial.print(buffer[pos] < 0x10 ? " 0" : " ");
        Serial.print(buffer[pos], HEX);
    }
}


bool Transaction::funcGetByteArray(SoftwareSerial &CardSerial)
{
  int cnt=0,j, compare=0,i,a,indexer=0;
  byte respBCC, temp;


  for(i=0; i<26; i++)
  {
    a=0;
    while (!(CardSerial.available()>0 ))   //if received
    {
      a++;
      delayMicroseconds(50);
      if (a>500)
        return false;
    }
    this->incomingByte[i]=CardSerial.read();
  } 
  return true;
}


bool Transaction::funcIsCardReaden(SoftwareSerial &CardSerial){
  int compare = 0;
  funcCardReadCmd(CardSerial);
  bool temp;
  temp = funcGetByteArray(CardSerial);
  if(temp)
  {
    //Aldaatai bol 
    if(!funcCheckReadenPacket(this->incomingByte, 26))
       Serial.println("ERROR");

    //Get current card UID numbers.
    int m=-1;
    for(int i=4; i<8; i++)
      currentCardUID[m++] = this->incomingByte[i];
          
    //when the device is turned on, Did read first card?
    if(powerOn == false){
       for(int i=0; i<5; i++){
          oldCardUID[i] = currentCardUID[i];
          startMillis = millis();  //initial start time
              //Serial.println("Powered ON");
       }
       powerOn = true;
    }

    //compare UIDs
    for(int m=0; m<4; m++)
    {
       if(oldCardUID[m]==currentCardUID[m])
          compare++;
    }
          //Serial.println((String)"Card compare number ==> "+compare);
        
    if(compare == 4){
       //Serial.println("Same Card");
       compare = 0;
       currentMillis = millis();
            
       if (currentMillis - startMillis >= period)  //test whether the period has elapsed
       {
              startMillis = currentMillis;  //IMPORTANT to save the start time of the current LED brightness
              //Serial.println("Daragdsan card bolowch 30 sec bolson");
              //sendPacketUSB(incomingByte, 26);
              funcSetBuzzerCardReader();
              this->cardReadStatus = true;
              for(int i=4; i<8; i++)
                transCardUID[i-4] = incomingByte[i];
              return true;
       }
    }
    else
    {
      //Serial.println("Another Card");
       for(int i=0; i<5; i++){
         oldCardUID[i] = currentCardUID[i];
         startMillis = millis();  //initial start time
       }
       //sendPacketUSB(incomingByte, 26);
       funcSetBuzzerCardReader();
       for(int i=4; i<8; i++)
                transCardUID[i-4] = incomingByte[i];
       this->cardReadStatus = true;
       return true;
    }
  }
  else{
    this->cardReadStatus = false;
    return false;
  } 
}    



// ======================== TRANSACTION LOGIC FUNCTION==================================================


//===========================ENVIRONMENT SENSOR VARIABLES===============================================
uint32_t currentTempValue;
uint16_t SEND_FRAME[16];
uint16_t RECIEVED_DATA[10];

String incomingBytes;
String subString;

int hum_val;  //Stores humidity value
int water_lvl;  //Stores water level value
int temp[10];
int smoke_val;

int waterLevelPin = A0;
int SMOKE_PIN = 24;
int sensorHumidityPin = 22;

void Transaction::funcGetSensorData(){
		
		DHT dht(sensorHumidityPin, DHTTYPE); //// Initialize DHT sensor for normal 16mhz Arduino
		dht.begin();
		hum_val = dht.readHumidity();
		water_lvl = analogRead(waterLevelPin);
		smoke_val = digitalRead(SMOKE_PIN);
		
		//clear sending frame	
		uint16_t CRC;
		uint8_t tempArr[50]={0};
		this->SENDING_FRAME[50]={0};
		
		//fill vals
		this->SENDING_FRAME[0] = PH1; // Packet header AB
		this->SENDING_FRAME[1] = PH2; // Packet header CD
		this->SENDING_FRAME[2] = CMD_envResp; // Command number
		this->SENDING_FRAME[3] = DATA_Len_envReq; // Data length
		
		temp1Serial.listen();
        if(temp1Serial.isListening()) 
        {
          incomingBytes=temp1Serial.readStringUntil('\n');
          subString = incomingBytes.substring(0, 4);
          currentTempValue=subString.toInt();
          this->SENDING_FRAME[4] = currentTempValue; //Ambient temperature
        }
		
		temp2Serial.listen();
        if(temp2Serial.isListening()) 
        {
          incomingBytes=temp2Serial.readStringUntil('\n');
          subString = incomingBytes.substring(0, 4);
          currentTempValue=subString.toInt();
          this->SENDING_FRAME[5] = currentTempValue;  //Ambient temperature
        } 
		
		this->SENDING_FRAME[6] = smoke_val; //Smoke sensor
		this->SENDING_FRAME[7] = hum_val; // Humidity sensor
		
		temp3Serial.listen();
        if(temp3Serial.isListening()) 
        {
          incomingBytes=temp3Serial.readStringUntil('\n');
          subString = incomingBytes.substring(0, 4);
          currentTempValue=subString.toInt();
          this->SENDING_FRAME[8] = currentTempValue;  //Boiler temperature
        } 
		
		temp4Serial.listen();
        if(temp4Serial.isListening()) 
        {
          incomingBytes=temp4Serial.readStringUntil('\n');
          subString = incomingBytes.substring(0, 4);
          currentTempValue=subString.toInt();
          this->SENDING_FRAME[9] = currentTempValue;  //Nozzle temperature
        } 
		
		temp5Serial.listen();
        if(temp5Serial.isListening()) 
        {
          incomingBytes=temp5Serial.readStringUntil('\n');
          subString = incomingBytes.substring(0, 4);
          currentTempValue=subString.toInt();
          this->SENDING_FRAME[10] = currentTempValue;  //KIOSK temperature
        }
		
		this->SENDING_FRAME[11] = water_lvl; // Water level sensor
		
		for(int i=2; i<12; i++)
			tempArr[i-2]=this->SENDING_FRAME[i];
		
		FastCRC16 CRC16;
		CRC = CRC16.kermit(tempArr, 10);
		
		this->SENDING_FRAME[12] = CRC & 0x00FF; // CRC LOW
		this->SENDING_FRAME[13] = (CRC & 0xFF00) >> 8; // CRC HIGH
		this->SENDING_FRAME[14] = ENDP1; // End of packet DC
		this->SENDING_FRAME[15] = ENDP2; // End of packet BA
		this->SENDING_FRAME[16] = NULL;

		for(int i=0; i<16; i++)
		{
			// Serial.print(this->SENDING_FRAME[i], HEX);
			// Serial.print(" ");
			Serial.write(SENDING_FRAME[i]);
		}  
    // Serial.println();
}