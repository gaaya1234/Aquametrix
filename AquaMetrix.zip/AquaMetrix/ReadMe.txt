This library for AquaMetrics device V@2 KIOSK.
