#ifndef AquaMetrics_h
#define AquaMetrics_h 
#include "Arduino.h"
#include <EEPROM.h>
#include <FastCRC.h>
#include <SoftwareSerial.h>
#include "DHT.h"

class Transaction{
  public: 
    //well internal variables
    uint16_t standbyDurationTime = 30000;
    uint16_t waterTankLevel = 0;
    uint64_t accumlatedWaterLitre = 0;

    //variables in each transaction
    uint8_t transWaterType; //0 means cold, 1 means hot
    uint16_t transHotWaterUnitPrice = 0;
    uint16_t transColdWaterUnitPrice = 0;
    uint8_t transCardUID[4]={0};
    uint32_t transCardBalance = 0;
    uint16_t transWaterMeter = 0;
    uint16_t transOldWaterMeter = 0;
    uint16_t transWaterLitre = 0;
    uint32_t transWaterAmount = 0;
    uint32_t transCounterNumber = 0;
    uint8_t transStatus=0x00; //01H means succesful, 0FH means failed transaction
    uint8_t transConfirmStatus; //11H means succesful, FFH means failed transaction
    bool cardReadStatus = false;
    bool transStarted = false;

    //internal serial buffers
    uint8_t SENDING_FRAME[50];
    uint8_t RECEIVED_FRAME[50];
    byte incomingByte[26];
    int buzzerPin=31;

    //Transaction functions
    bool funcCheckCRCpacket(uint8_t *buffer, uint8_t bufferSize);    //Checked
    bool funcReadSerial(SoftwareSerial &DataSerial);
    bool funcRespRaspberry(SoftwareSerial &DataSerial);  //
    uint8_t *funcSendCardReqCmd();     //checked
    uint8_t *funcSendTransInfoCmd();    //Checked

	void funcGetSensorData();

    //Card Reader functions ISO14443A communication
    void funcSetBuzzerCardReader();
    byte funcCheckBCC(byte card_data_length, byte cmdType); //check packet BCC
    void funcDumpByteArray(byte *buffer, byte bufferSize, SoftwareSerial &ChosenSerial); //Send packet via desired serial port
    byte *funcCardReadCmd(SoftwareSerial &CardSerial); //Card read cmd
    byte *funcCardWriteCmd();
    void sendPacketUSB(byte *buffer, byte bufferSize);
    boolean funcCheckReadenPacket(byte *buffer, byte bufferSize);  //Readen packet BCC is right? validation part
    bool funcGetByteArray(SoftwareSerial &CardSerial);
    bool funcIsCardReaden(SoftwareSerial &CardSerial);
};


class AquaMetrics:public Transaction{
  
  public:
    // Well Pins
    int waterLevelPin;
    int waterMeterPin;
    int nozzleStatePin;
    int valveHotWaterRelayPin;
    int valveColdWaterRelayPin;
    int waterHotButtonPin;
    int waterColdButtonPin;
    int waterStopButtonPin;
    int buzzerPin;
    int displayEnablePin;
    int displayCLKPin;
    int displayDataPin;
    int sensorSmokePin;
	int sensorHumidityPin; //DHTTYPE DHT11   // DHT 22  (AM2302)
		
    // Well Variables
    bool valveHotWaterRelay;
    bool valveColdWaterRelay;
    bool waterHotButtonPressed = false;
    bool waterColdButtonPressed = false;
    bool waterStopButtonPressed = false;
    bool nozzleState = false; //0 means nozzle Up, 1 means nozzle Down
   
  

    //constructor  
    AquaMetrics(int waterLevelPin,
    int waterMeterPin,
    int nozzleStatePin,
    int valveHotWaterRelayPin,
    int valveColdWaterRelayPin,
    int waterHotButtonPin,
    int waterColdButtonPin,
    int waterStopButtonPin,
    int buzzerPin,
    int displayEnablePin,
    int displayCLKPin,
    int displayDataPin,
	int sensorSmokePin,
	int sensorHumidityPin);

    void init();//initialize
    void funcSetBuzzer1();
    void funcSetBuzzer2();
    int funcGetWaterlevel();
    //uint16_t funcGetWaterMeter();
    bool funcGetNozzleState();
    bool funcSetWaterValve(bool setType,uint8_t valve);
    void funcButtonPressed(int buttonPin);
    void funcIsButtonPressed();
    void funcLCDinit();
    void funcLCDclkGenerator();
    void funcLCDenableGenerator();
    void funcLCDprint(int numbers);
    void funcLCDanimation();
    void funcLCDclear();
    void funcLCDdisplay(uint16_t totalAmount, uint16_t unitPrice, int animCounter); //current Litre with Unitprice
    void funcLCDdisplayError(uint8_t Status); //Display error function
    void funcLCDdisplayBalance(uint32_t cardBalance); //Display card Balance

	

    // uint16_t funcEEPROMwriteList(uint16_t transCounter, uint8_t *transactionData);
    // uint8_t * funcEEPROMreadList(uint16_t transCounter);
    // void funcTransferEEPROMdata();

    void funcErrorTransactionTime(SoftwareSerial &raspberrySerial);
    void funcErrorUserBalance(SoftwareSerial &raspberrySerial);
    void funcErrorWaterTank(SoftwareSerial &raspberrySerial);
    void funcCancelTransaction(SoftwareSerial &raspberrySerial); 
    void funcEndTransaction(SoftwareSerial &raspberrySerial);

};


#endif