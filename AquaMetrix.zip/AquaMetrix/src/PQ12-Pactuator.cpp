#include "Arduino.h"
#include "PQ12-Pactuator.h"

class LinearMotor {
  public:
    int motorNumber;
    int pinFeedback;
    int directionPin;
    int pwmPin;
    int enablePin;
    
    int currentPosition;
    int desiredPosition;
    byte done = false;

    LinearMotor(int motorNumber, int pinFeedback, int directionPin, int pwmPin, int enablePin);//constructor  
    void init();//initialize
    int getPosition(); // to get position
    byte stopMotor();
    byte setToPosition(int pos); // set to a position
    void funcDirection();
};

LinearMotor::LinearMotor(int motorNumber, int pinFeedback, int directionPin, int pwmPin, int enablePin) { //constructor
  this->motorNumber = motorNumber;
  this->pinFeedback = pinFeedback;
  this->directionPin = directionPin;
  this->pwmPin = pwmPin;
  this->enablePin = enablePin;
  
  init();
}

void LinearMotor::init() { //initialize
  pinMode(pinFeedback, INPUT);
  pinMode(directionPin, OUTPUT);
  pinMode(pwmPin, OUTPUT);
  pinMode(enablePin, OUTPUT);
  digitalWrite(enablePin, LOW);
  digitalWrite(pwmPin, LOW);
}

int LinearMotor::getPosition(){  // to get position
  int value;
  return currentPosition = analogRead(this->pinFeedback);
}

byte LinearMotor::stopMotor(){
  digitalWrite(this->pwmPin, LOW);
  //digitalWrite(this->enablePin, HIGH);
  return 1;
}

void LinearMotor::funcDirection(){  
  if((desiredPosition - getPosition()) > 0)
    digitalWrite(directionPin, HIGH);
  else
    digitalWrite(directionPin, LOW);
}