#ifndef LinearMotor_h
#define LinearMotor_h 
#include "Arduino.h"

class LinearMotor {
  
  public:
    
    int motorNumber;
    int pinFeedback;
    int directionPin;
    int pwmPin;
    int enablePin;
    
    int currentPosition;
    int desiredPosition;
    byte done = false;
    
    LinearMotor(int motorNumber, int pinFeedback, int directionPin, int pwmPin, int enablePin);//constructor  
    void init();//initialize
    int getPosition(); // to get position
    byte stopMotor();
    byte setToPosition(int pos); // set to a position
    void funcDirection();
};

#endif